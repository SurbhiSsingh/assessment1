import { MockDexRouter } from "../src/services/MockDexRouter";

describe("MockDexRouter", () => {
  it("should return a quote from raydium and meteora and choose best", async () => {
    const r = new MockDexRouter();
    const best = await r.getBestQuote("SOL", "USDC", 1);
    expect(best).toHaveProperty("price");
    expect(["raydium","meteora"]).toContain(best.dex);
  });
});
