import { Worker } from "bullmq";
import IORedis from "ioredis";
import { MockDexRouter } from "./services/MockDexRouter";
import { wsSend } from "./wsManager";
import { saveOrderResult } from "./db";

const connection = new IORedis(process.env.REDIS_URL || "redis://127.0.0.1:6379");
const CONCURRENCY = process.env.QUEUE_CONCURRENCY ? parseInt(process.env.QUEUE_CONCURRENCY) : 10;

export async function startWorker() {
  const router = new MockDexRouter();

  const worker = new Worker(
    "orders",
    async (job) => {
      const order = job.data;
      wsSend.send(order.id, { status: "pending" });
      wsSend.send(order.id, { status: "routing" });
      const best = await router.getBestQuote(order.tokenIn, order.tokenOut, order.amount);

      wsSend.send(order.id, { status: "building", chosenDex: best.dex, quote: best });
      wsSend.send(order.id, { status: "submitted" });
      try {
        const res = await router.executeSwap(best.dex, order);
        wsSend.send(order.id, { status: "confirmed", txHash: res.txHash, executedPrice: res.executedPrice });
        await saveOrderResult(order.id, "confirmed", res.txHash, res.executedPrice, best.dex);
        return { txHash: res.txHash };
      } catch (err: any) {
        wsSend.send(order.id, { status: "failed", error: err.message });
        await saveOrderResult(order.id, "failed", null, null, best.dex, err.message);
        throw err; 
      }
    },
    { connection, concurrency: CONCURRENCY }
  );

  worker.on("failed", (job, err) => {
    console.error(`Job ${job?.id} failed:`, err?.message);
  });

  worker.on("completed", (job) => {
    console.log(`Job ${job?.id} completed`);
  });

  console.log("Worker started with concurrency", CONCURRENCY);
}
