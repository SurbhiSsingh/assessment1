import { FastifyInstance } from "fastify";
import { v4 as uuidv4 } from "uuid";
import { addOrderToQueue } from "../queue/orderQueue";
import { wsSend } from "../wsManager";

export default async function routes(fastify: FastifyInstance) {
  fastify.post("/execute", async (request, reply) => {
    const body = request.body as any || {};
    const orderId = uuidv4();
    const order = {
      id: orderId,
      type: body.type || "market",
      tokenIn: body.tokenIn || "SOL",
      tokenOut: body.tokenOut || "USDC",
      amount: body.amount || 1,
      createdAt: new Date().toISOString()
    };

    await addOrderToQueue(order);

    return reply.send({
      orderId,
      wsUpgradeHint: `/api/orders/execute (upgrade to WebSocket and send JSON { "orderId":"${orderId}" })`
    });
  });

  fastify.get("/execute", { websocket: true }, (connection /* SocketStream */, req) => {
    const socket = connection.socket;
    socket.on("message", (msg) => {
      try {
        const parsed = JSON.parse(msg.toString());
        if (parsed.orderId) {
          (fastify as any).wsConnections.set(parsed.orderId, socket);
          // initial ack
          socket.send(JSON.stringify({ orderId: parsed.orderId, status: "connected" }));
        } else {
          socket.send(JSON.stringify({ error: "send { orderId } to subscribe" }));
        }
      } catch (err) {
        socket.send(JSON.stringify({ error: "invalid json" }));
      }
    });

    socket.on("close", () => {
      for (const [orderId, s] of (fastify as any).wsConnections.entries()) {
        if (s === socket) (fastify as any).wsConnections.delete(orderId);
      }
    });
  });

  wsSend.registerFastifyInstance(fastify);
}
