import { Queue } from "bullmq";
import IORedis from "ioredis";

const connection = new IORedis(process.env.REDIS_URL || "redis://127.0.0.1:6379");
export const orderQueue = new Queue("orders", { connection });

export async function addOrderToQueue(order: any) {
  await orderQueue.add(order.id, order, {
    attempts: 3,
    backoff: { type: "exponential", delay: 1000 },
    removeOnComplete: 10,
    removeOnFail: 10
  });
}
