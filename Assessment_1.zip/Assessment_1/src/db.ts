import { Client } from "pg";

const connString = process.env.PG_CONNECTION || "postgresql://postgres:postgres@localhost:5432/order_engine";
const client = new Client({ connectionString: connString });

export async function initDb() {
  await client.connect();
  await client.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
      status TEXT,
      tx_hash TEXT,
      executed_price NUMERIC,
      dex TEXT,
      error TEXT
    );
  `);
  console.log("DB initialized");
}

export async function saveOrderResult(orderId: string, status: string, txHash: string | null, executedPrice: number | null, dex: string, error: string | null = null) {
  await client.query(
    `INSERT INTO orders(id, status, tx_hash, executed_price, dex, error)
     VALUES($1,$2,$3,$4,$5,$6)
     ON CONFLICT (id) DO UPDATE SET status = EXCLUDED.status, tx_hash = EXCLUDED.tx_hash, executed_price = EXCLUDED.executed_price, dex = EXCLUDED.dex, error = EXCLUDED.error;`,
    [orderId, status, txHash, executedPrice, dex, error]
  );
}
