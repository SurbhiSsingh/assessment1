function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export type Quote = { price: number; fee: number; dex: string };

export class MockDexRouter {
  basePrice = 100; 
  async getRaydiumQuote(tokenIn: string, tokenOut: string, amount: number): Promise<Quote> {
    await sleep(200 + Math.random() * 200);
    const price = this.basePrice * (0.98 + Math.random() * 0.04); // 2% variance
    return { price, fee: 0.003, dex: "raydium" };
  }

  async getMeteoraQuote(tokenIn: string, tokenOut: string, amount: number): Promise<Quote> {
    await sleep(200 + Math.random() * 200);
    const price = this.basePrice * (0.97 + Math.random() * 0.05);
    return { price, fee: 0.002, dex: "meteora" };
  }

  async getBestQuote(tokenIn: string, tokenOut: string, amount: number) {
    const [r, m] = await Promise.all([
      this.getRaydiumQuote(tokenIn, tokenOut, amount),
      this.getMeteoraQuote(tokenIn, tokenOut, amount)
    ]);
    return r.price <= m.price ? r : m;
  }

  async executeSwap(dex: string, order: any): Promise<{ txHash: string; executedPrice: number }> {
    await sleep(2000 + Math.random() * 1000);
    if (Math.random() < 0.05) throw new Error("Simulated chain failure");
    const executedPrice = this.basePrice * (0.98 + Math.random() * 0.05);
    const txHash = "MOCKTX_" + Math.random().toString(36).slice(2, 10);
    return { txHash, executedPrice };
  }
}
