import { FastifyInstance } from "fastify";

let fastifyInstance: FastifyInstance | null = null;

export function registerFastifyInstance(fastify: FastifyInstance) {
  fastifyInstance = fastify;
}

export const wsSend = {
  registerFastifyInstance,
  send: (orderId: string, payload: any) => {
    try {
      if (!fastifyInstance) {
        console.warn("wsSend: fastify not registered");
        return;
      }
      
    } catch (err) {
      console.error("wsSend error", err);
    }
  }
};
