import { startServer } from "./server";
import { initDb } from "./db";
import { startWorker } from "./worker";

(async () => {
  await initDb();
  const fastify = await startServer();
  const port = process.env.PORT ? parseInt(process.env.PORT) : 3000;
  fastify.listen({ port, host: "0.0.0.0" }, (err, address) => {
    if (err) {
      console.error("Server failed:", err);
      process.exit(1);
    }
    console.log(`Server listening at ${address}`);
  });
}