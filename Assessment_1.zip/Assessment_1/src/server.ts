import Fastify from "fastify";
import fastifyWebsocket from "fastify-websocket";
import ordersRoute from "./routes/orders";

export async function startServer() {
  const fastify = Fastify({ logger: true });
  fastify.decorate("wsConnections", new Map<string, any>());
  fastify.register(ordersRoute, { prefix: "/api/orders" });
  fastify.get("/health", async () => ({ ok: true }));

  return fastify;
}
