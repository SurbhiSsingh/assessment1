declare module 'fastify-websocket';
