
A mock order execution engine demonstrating:
- Market order processing
- DEX routing between Raydium & Meteora (mocked)
- WebSocket live updates for order lifecycle
- Queue processing using BullMQ & Redis
- Order persistence to PostgreSQL


